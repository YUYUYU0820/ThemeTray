ThemeTray v1.02 - Windows 深浅色切换

使用方法：
1. 确认已安装 x64 .NET 8 Windows Desktop Runtime。
2. 解压后双击 ThemeTray.exe 运行。
3. 程序启动后会出现在 Windows 任务栏右下角托盘区。
4. 左键或右键点击托盘图标，可打开菜单并切换深浅色、设置自动切换、开机自启等。

运行环境：
- Windows 10 1809（17763）或更高版本。
- x64 .NET 8 Windows Desktop Runtime。

说明：
- 本版本为依赖 .NET 运行时的单文件版本，以减小下载体积。
- 日出日落、Windows 定位、自动切换、开机自启等功能均保留。
- 如果 Windows SmartScreen 提示未知发布者，这是因为程序未做代码签名；确认来源可信后可选择继续运行。
